#!/bin/bash
for arg in "$@"; do
   case "$arg" in
      collector=*) collector="${arg#*=}" ;;
   esac
done

mkdir ${collector}-processed
files=($(ls ${collector}-raw/* | sort -Vt / -k2,2))
for (( i=0; i<${#files[*]}; i+=4 ));
do
  filename="${files[i]##*/}"
  gs -q -dNOPAUSE -dBATCH -sDEVICE=pdfwrite \
  -dDEVICEWIDTHPOINTS=792 -dDEVICEHEIGHTPOINTS=612 \
  -sOutputFile=${collector}-processed/$filename \
  "${files[$i]}" "${files[$((i+1))]}" "${files[$((i+2))]}" "${files[$((i+3))]}"
done

mkdir ../final
files=($(ls ${collector}-processed/* | sort -Vt / -k2,2))
pdftk ${files[*]} output ../final/${collector}-labels.pdf

echo "final labels are located at: final/${collector}-labels.pdf"
